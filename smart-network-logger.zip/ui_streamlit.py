# ui_streamlit.py
# Simple Streamlit UI to display flows and anomalies

import streamlit as st
import pandas as pd
import time
from pathlib import Path

st.set_page_config(page_title='Smart Network Logger', layout='wide')

st.title('Smart Network Logger — Live Flows & Anomalies')

CSV_PATH = 'flows_scored.csv'

st.sidebar.header('Settings')
refresh = st.sidebar.slider('Refresh interval (s)', 1, 30, 5)
show_only_anomalies = st.sidebar.checkbox('Show only anomalies', value=False)

placeholder = st.empty()

while True:
    try:
        df = pd.read_csv(CSV_PATH)
    except Exception:
        df = pd.DataFrame()

    if not df.empty:
        if show_only_anomalies:
            df = df[df['anomaly'] == 1]
        # show top by score
        df_display = df.sort_values('anomaly_score')  # lower is more anomalous in sklearn
        placeholder.table(df_display.head(50))
    else:
        placeholder.info('Waiting for scored flows...')

    time.sleep(refresh)
