# Smart Network Logger — Runnable Project & Docker setup

This archive contains a runnable version of the **Smart Network Logger** proof-of-concept (extracted from the provided `.docx`) plus a Dockerfile and `docker-compose.yml` for easy deployment.

## Contents
- `capture.py` — live packet sniffer using Scapy (writes packet CSV).
- `features.py` — aggregate packets into flows and compute features.
- `detector.py` — train & score IsolationForest model.
- `dataset_generator.py` — synthetic dataset generator (normal + anomalies).
- `ui_streamlit.py` — Streamlit UI to display flows & anomalies.
- `requirements.txt` — Python dependencies.
- `run.sh` — convenience script to run the demo locally.
- `Dockerfile` — Docker image for the app (Streamlit UI & detector).
- `docker-compose.yml` — compose service to run the app.
- `.dockerignore` — files to ignore in Docker build.

## Quick start (local)
1. Create a venv and install deps:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

2. Generate dataset, train model, and score flows:
```bash
python dataset_generator.py
python detector.py --train synthetic_flows.csv --model model.iforest.joblib
python detector.py --score synthetic_flows.csv --model model.iforest.joblib
```

3. Run Streamlit UI:
```bash
streamlit run ui_streamlit.py
```

## Quick start (Docker)
Build & run:
```bash
docker-compose up --build
```

Open http://localhost:8501 to view the UI.

**Notes:** Capturing live traffic with `capture.py` requires host network access and special capabilities (e.g., `CAP_NET_RAW`). Running the sniffer inside a container requires extra care — for testing, use the synthetic dataset and scoring pipeline included here.
