# features.py
# Convert raw packet CSV into flow-aggregated features.

import pandas as pd
import numpy as np

# Choose a flow key: 5-tuple (src, dst, sport, dport, proto)

FLOW_WINDOW = 60  # seconds to aggregate into a flow record (sliding or tumbling)


def load_packets(csv_path):
    df = pd.read_csv(csv_path)
    # ensure types
    df['ts'] = pd.to_numeric(df['ts'], errors='coerce')
    df['length'] = pd.to_numeric(df['length'], errors='coerce')
    return df.dropna(subset=['ts'])


def build_flows(df, window=FLOW_WINDOW):
    # Simple tumbling-window-based flow aggregation by 5-tuple + window start
    df = df.copy()
    df['window_start'] = (df['ts'] // window) * window
    df['flow_key'] = df['src_ip'].astype(str) + '|' + df['dst_ip'].astype(str) + '|' + df['proto'].astype(str) + '|' + df['window_start'].astype(int).astype(str)

    groups = df.groupby('flow_key')

    rows = []
    for key, g in groups:
        row = {}
        row['flow_key'] = key
        row['src_ip'] = g['src_ip'].iloc[0]
        row['dst_ip'] = g['dst_ip'].iloc[0]
        row['proto'] = g['proto'].iloc[0]
        row['start_ts'] = g['ts'].min()
        row['end_ts'] = g['ts'].max()
        row['duration'] = row['end_ts'] - row['start_ts'] if row['end_ts'] != row['start_ts'] else 0.0
        row['packet_count'] = len(g)
        row['byte_count'] = g['length'].sum()
        row['avg_pkt_len'] = g['length'].mean()
        # inter-arrival features
        times = np.sort(g['ts'].values)
        if len(times) > 1:
            iat = np.diff(times)
            row['iat_mean'] = iat.mean()
            row['iat_std'] = iat.std()
        else:
            row['iat_mean'] = 0.0
            row['iat_std'] = 0.0
        # flags ratio
        try:
            flags = pd.to_numeric(g['tcp_flags'], errors='coerce').fillna(0)
            row['syn_count'] = int((flags & 0x02).astype(bool).sum())
            row['ack_count'] = int((flags & 0x10).astype(bool).sum())
        except Exception:
            row['syn_count'] = 0
            row['ack_count'] = 0

        rows.append(row)

    feat_df = pd.DataFrame(rows)
    # fill na and set types
    for col in ['packet_count', 'byte_count', 'avg_pkt_len', 'iat_mean', 'iat_std', 'syn_count', 'ack_count', 'duration']:
        if col in feat_df.columns:
            feat_df[col] = pd.to_numeric(feat_df[col], errors='coerce').fillna(0.0)

    return feat_df


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--in', dest='infile', default='logs/packets.csv')
    parser.add_argument('--out', dest='outfile', default='flows.csv')
    args = parser.parse_args()

    df = load_packets(args.infile)
    flows = build_flows(df)
    flows.to_csv(args.outfile, index=False)
    print('Wrote', args.outfile)
