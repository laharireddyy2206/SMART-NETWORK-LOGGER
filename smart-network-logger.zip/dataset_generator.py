# dataset_generator.py
# Create synthetic flows for testing: normal web chat/ssh-looking traffic and some anomalies (scans, heavy bursts)

import pandas as pd
import numpy as np
import random

FEATURE_COLUMNS = ['packet_count', 'byte_count', 'avg_pkt_len', 'iat_mean', 'iat_std', 'syn_count', 'ack_count', 'duration']


def gen_normal(n=1000):
    rows = []
    for _ in range(n):
        packet_count = np.random.poisson(5)
        byte_count = packet_count * np.random.normal(500, 100)
        avg_pkt_len = byte_count / max(1, packet_count)
        iat_mean = np.random.exponential(0.1)
        iat_std = iat_mean * 0.5
        syn_count = np.random.binomial(packet_count, 0.1)
        ack_count = np.random.binomial(packet_count, 0.7)
        duration = np.random.exponential(1.0)
        rows.append([packet_count, abs(byte_count), avg_pkt_len, iat_mean, iat_std, syn_count, ack_count, duration])
    return pd.DataFrame(rows, columns=FEATURE_COLUMNS)


def gen_anomalies(n=50):
    rows = []
    for _ in range(n):
        # choose a type: port scan (many short packets) or traffic flood (huge bytes)
        if random.random() < 0.6:
            # scan
            packet_count = np.random.poisson(200)
            byte_count = packet_count * np.random.normal(60, 10)
            avg_pkt_len = 60
            iat_mean = 0.001
            iat_std = 0.0005
            syn_count = int(packet_count * 0.9)
            ack_count = int(packet_count * 0.01)
            duration = 0.5
        else:
            # flood
            packet_count = np.random.poisson(1000)
            byte_count = packet_count * np.random.normal(1200, 300)
            avg_pkt_len = 1200
            iat_mean = 0.0005
            iat_std = 0.0002
            syn_count = int(packet_count * 0.2)
            ack_count = int(packet_count * 0.2)
            duration = 2.0
        rows.append([packet_count, abs(byte_count), avg_pkt_len, iat_mean, iat_std, syn_count, ack_count, duration])
    return pd.DataFrame(rows, columns=FEATURE_COLUMNS)


if __name__ == '__main__':
    normal = gen_normal(2000)
    anomalies = gen_anomalies(100)
    normal['label'] = 0
    anomalies['label'] = 1
    data = pd.concat([normal, anomalies], ignore_index=True)
    data.sample(frac=1, random_state=42).to_csv('synthetic_flows.csv', index=False)
    print('Wrote synthetic_flows.csv with shape', data.shape)
