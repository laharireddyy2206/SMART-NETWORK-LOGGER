# detector.py
# Train an IsolationForest on features and then run scoring.

import pandas as pd
from sklearn.ensemble import IsolationForest
from joblib import dump, load
import numpy as np

MODEL_PATH = 'model.iforest.joblib'

FEATURE_COLUMNS = ['packet_count', 'byte_count', 'avg_pkt_len', 'iat_mean', 'iat_std', 'syn_count', 'ack_count', 'duration']


def train_model(train_csv, out_model=MODEL_PATH):
    df = pd.read_csv(train_csv)
    X = df[FEATURE_COLUMNS].fillna(0.0)
    # simple scaler
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)

    clf = IsolationForest(n_estimators=200, contamination=0.01, random_state=42)
    clf.fit(Xs)

    dump({'model': clf, 'scaler': scaler}, out_model)
    print('Saved model to', out_model)


def score_flows(flow_csv, model_path=MODEL_PATH, out_csv=None):
    data = pd.read_csv(flow_csv)
    payload = load(model_path)
    clf = payload['model']
    scaler = payload['scaler']

    X = data[FEATURE_COLUMNS].fillna(0.0)
    Xs = scaler.transform(X)

    scores = clf.decision_function(Xs)
    preds = clf.predict(Xs)  # -1 anomaly, 1 normal

    data['anomaly_score'] = scores
    data['anomaly'] = (preds == -1).astype(int)

    if out_csv:
        data.to_csv(out_csv, index=False)
    return data


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--train', help='CSV with flows for training')
    parser.add_argument('--score', help='CSV with flows to score')
    parser.add_argument('--model', default=MODEL_PATH)
    args = parser.parse_args()

    if args.train:
        train_model(args.train, args.model)
    if args.score:
        out = score_flows(args.score, args.model, out_csv='flows_scored.csv')
        print('Scored flows. Example:')
        print(out.head())
