#!/usr/bin/env python3
# capture.py
# Run as root (or with network capabilities) to sniff live network traffic.
# Usage: python capture.py --iface eth0 --out logs/packets.csv

import argparse
import csv
import time
from scapy.all import sniff
from scapy.layers.inet import IP, TCP, UDP

FIELDNAMES = [
    'ts', 'src_ip', 'src_port', 'dst_ip', 'dst_port', 'proto', 'length', 'tcp_flags'
]


def pkt_to_record(pkt):
    ts = time.time()
    src_ip = pkt[IP].src if IP in pkt else None
    dst_ip = pkt[IP].dst if IP in pkt else None
    length = len(pkt)
    proto = None
    src_port = None
    dst_port = None
    tcp_flags = ''

    if TCP in pkt:
        proto = 'TCP'
        src_port = pkt[TCP].sport
        dst_port = pkt[TCP].dport
        # scapy's flags may be of FlagValue type; convert to int if possible
        try:
            tcp_flags = int(pkt[TCP].flags)
        except Exception:
            tcp_flags = str(pkt[TCP].flags)
    elif UDP in pkt:
        proto = 'UDP'
        src_port = pkt[UDP].sport
        dst_port = pkt[UDP].dport
    else:
        proto = pkt.lastlayer().name if pkt.lastlayer() is not None else 'OTHER'

    return {
        'ts': ts,
        'src_ip': src_ip,
        'src_port': src_port,
        'dst_ip': dst_ip,
        'dst_port': dst_port,
        'proto': proto,
        'length': length,
        'tcp_flags': tcp_flags
    }


class CSVWriter:
    def __init__(self, path):
        self.path = path
        Path = __import__('pathlib').Path
        p = Path(self.path)
        p.parent.mkdir(parents=True, exist_ok=True)
        self.file = open(self.path, 'a', newline='')
        self.writer = csv.DictWriter(self.file, fieldnames=FIELDNAMES)
        # write header if empty
        if self.file.tell() == 0:
            self.writer.writeheader()

    def write(self, rec):
        self.writer.writerow(rec)
        self.file.flush()

    def close(self):
        self.file.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--iface', default=None, help='Interface to sniff (optional)')
    parser.add_argument('--out', default='logs/packets.csv', help='CSV file to append packet records')
    parser.add_argument('--count', type=int, default=0, help='Number of packets to capture (0 = forever)')
    args = parser.parse_args()

    writer = CSVWriter(args.out)

    def on_pkt(pkt):
        if IP in pkt:
            rec = pkt_to_record(pkt)
            writer.write(rec)

    print('Starting sniff on', args.iface or 'any')
    sniff(iface=args.iface, prn=on_pkt, store=False, count=args.count)

    writer.close()


if __name__ == '__main__':
    main()
