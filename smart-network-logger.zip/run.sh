#!/usr/bin/env bash
# run.sh - convenience script to run components (for development only)
set -e
python3 -m venv .venv || true
source .venv/bin/activate
pip install -r requirements.txt
python dataset_generator.py
python detector.py --train synthetic_flows.csv --model model.iforest.joblib
python detector.py --score synthetic_flows.csv --model model.iforest.joblib
echo "To run the UI: streamlit run ui_streamlit.py"
